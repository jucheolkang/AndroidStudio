package my.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {
TextView su_id, su_pw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        su_id = (TextView) findViewById(R.id.textView);
        su_pw = (TextView) findViewById(R.id.textView2);
        Button btn_ok = (Button) findViewById(R.id.btn_ok) ;



        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        String pw = intent.getStringExtra("pw");
        su_id.setText(id);
        su_pw.setText(pw);
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(SubActivity.this,MainActivity.class);
                intent1.putExtra("Result","로그인 성공");
                setResult(RESULT_OK,intent1);
                finish();
            }
        });

    }




}