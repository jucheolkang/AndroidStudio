package my.loginapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
Button btn1, btn2;
TextView text;
int count = 0;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        text = (TextView) findViewById(R.id.textView4);
        btn1 = (Button) findViewById(R.id.btn1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                text.setText("현재 개수 = " + count);
            }
        });
        btn2 = (Button) findViewById(R.id.btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count--;
                text.setText("현재 개수 = " + count);
            }
        });
        if(savedInstanceState != null){
            count = savedInstanceState.getInt("count");// 번들이 가지고 있는 count 변수의 값을 꺼내온다
            text.setText("현재 개수 = " + count);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("count",count);// 번들 객체가 지고있는 count에 값을 다시 저장한다
    }
}
// 회전을 하게 되면 화면이 새로 갱신되는데 이때 가지고 있는 값을 유지하기 위해서 bundle을 이용한다.