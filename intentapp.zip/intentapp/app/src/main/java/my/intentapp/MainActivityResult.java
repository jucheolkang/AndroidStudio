package my.intentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivityResult extends AppCompatActivity {
    static final int GET_RESULT = 1;
    TextView text;
    private EditText edit1, edit2, edit3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_result);
        Button button  = (Button) findViewById(R.id.butt);
        edit1 = (EditText) findViewById(R.id.edit1);
        edit2 = (EditText) findViewById(R.id.edit2);
        edit3 = (EditText) findViewById(R.id.edit3);


        button.setOnClickListener(new View.OnClickListener(){

//            @Override
            public void onClick(View arg0) {
                Intent in = new Intent(MainActivityResult.this,SendActivity.class);
                in.putExtra("number1",Integer.parseInt(edit1.getText().toString()));
                in.putExtra("number2",Integer.parseInt(edit2.getText().toString()));
                startActivityForResult(in,GET_RESULT);
            }//putExtra - intent시 데이터 주기



        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GET_RESULT) {
            if (resultCode == RESULT_OK) {
                edit3.setText("" + data.getIntExtra("RESULT", 0));

            }
        }
    }
}